import createPageUrl from './createPageUrl';

export { createPageUrl };