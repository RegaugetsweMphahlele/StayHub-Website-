import React from "react";
import { Search, MapPin } from "lucide-react";
import { Container, Row, Col, Button, Form, InputGroup } from "react-bootstrap";

export default function HeroSection({ searchQuery, setSearchQuery, onSearch }) {
  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      onSearch();
    }
  };

  return (
    <div className="text-white py-5 py-md-8 position-relative overflow-hidden" style={{ backgroundColor: "#2C3E50" }}>
      {/* Background decoration elements */}
      <div className="position-absolute top-0 start-0 w-100 h-100 bg-black opacity-10"></div>
      <div className="position-absolute top-0 end-0 w-96 h-96 bg-white opacity-10 rounded-circle blur"
           style={{
             transform: 'translate(8rem, -8rem)',
             filter: 'blur(48px)'
           }}></div>
      <div className="position-absolute bottom-0 start-0 w-96 h-96 bg-white opacity-10 rounded-circle blur"
           style={{
             transform: 'translate(-8rem, 8rem)',
             filter: 'blur(48px)'
           }}></div>

      <Container className="position-relative z-1">
        <Row className="justify-content-center text-center mb-5">
          <Col lg={8}>
            <h1 className="display-4 fw-bold mb-3 text-white">
              Find Your Perfect
              <br />
              <span className="d-block text-white">Stay in South Africa</span>
            </h1>
            <p className="lead" style={{ color: "#ECF0F1" }}>
              Discover unique accommodations across the Rainbow Nation, from Cape Town to Johannesburg
            </p>
          </Col>
        </Row>

        {/* Search bar */}
        <Row className="justify-content-center mb-5">
          <Col lg={8} xl={6}>
            <InputGroup>
              <InputGroup.Text className="bg-white border-0">
                <MapPin size={18} className="text-primary" />
              </InputGroup.Text>
              <Form.Control
                type="text"
                placeholder="Where in South Africa do you want to go?"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={handleKeyPress}
                className="border-0 py-3 px-4 fs-5"
                style={{ height: '60px' }}
              />
              <Button
                onClick={onSearch}
                className="px-4 py-3 fs-5 border-0"
                style={{ 
                  height: '60px', 
                  backgroundColor: "#3498DB",
                }}
              >
                <Search size={18} className="me-2" />
                Search
              </Button>
            </InputGroup>
          </Col>
        </Row>

        {/* Quick stats */}
        <Row className="text-center g-4">
          <Col md={4}>
            <div className="rounded-3 py-4 px-3" style={{ backgroundColor: "#34495E" }}>
              <div className="display-6 fw-bold text-white">50+</div>
              <div className="text-white">Properties Available</div>
            </div>
          </Col>
          <Col md={4}>
            <div className="rounded-3 py-4 px-3" style={{ backgroundColor: "#34495E" }}>
              <div className="display-6 fw-bold text-white">1000+</div>
              <div className="text-white">Happy Guests</div>
            </div>
          </Col>
          <Col md={4}>
            <div className="rounded-3 py-4 px-3" style={{ backgroundColor: "#34495E" }}>
              <div className="display-6 fw-bold text-white">24/7</div>
              <div className="text-white">Customer Support</div>
            </div>
          </Col>
        </Row>
      </Container>
    </div>
  );
}